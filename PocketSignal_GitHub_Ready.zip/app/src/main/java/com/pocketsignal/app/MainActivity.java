package com.pocketsignal.app;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;

public class MainActivity extends Activity {
    int win=18, loss=0; boolean buy=true;
    LinearLayout root, card; TextView winT, lossT, rateT, signalT, clockT;

    TextView tv(String s,int size){ TextView t=new TextView(this); t.setText(s); t.setTextColor(Color.WHITE); t.setTextSize(size); t.setGravity(Gravity.CENTER); t.setPadding(8,8,8,8); return t; }
    GradientDrawable bg(int color,int radius){ GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(radius); return g; }

    @Override public void onCreate(Bundle b){super.onCreate(b); build(); new Handler().post(new Runnable(){public void run(){ clockT.setText(new java.text.SimpleDateFormat("HH:mm:ss").format(new java.util.Date())+" UTC+3"); new Handler().postDelayed(this,1000);}});}

    void build(){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(28,22,28,22); root.setBackgroundColor(Color.rgb(7,21,47));
        ScrollView sv=new ScrollView(this); sv.addView(root); setContentView(sv);

        TextView title=tv("Pocket Signal                         ● LIVE",22); title.setTypeface(null,1); root.addView(title,new LinearLayout.LayoutParams(-1,70));
        card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(24,20,24,20); card.setBackground(bg(Color.rgb(14,50,100),40));
        root.addView(card,new LinearLayout.LayoutParams(-1,-2));

        LinearLayout head=new LinearLayout(this); head.setGravity(Gravity.CENTER_VERTICAL);
        TextView asset=tv("AUD/CAD OTC",20); asset.setTextColor(Color.rgb(117,239,77)); asset.setTypeface(null,1);
        clockT=tv("",12); head.addView(asset,new LinearLayout.LayoutParams(0,70,1)); head.addView(clockT,new LinearLayout.LayoutParams(-2,70)); card.addView(head);

        TextView live=tv("L I V E   T R A D E S",13); live.setTextColor(Color.LTGRAY); card.addView(live);

        LinearLayout stats=new LinearLayout(this); stats.setGravity(Gravity.CENTER);
        LinearLayout wbox=new LinearLayout(this); wbox.setOrientation(LinearLayout.VERTICAL); winT=tv("18",44); winT.setTextColor(Color.rgb(101,238,78)); wbox.addView(tv("WIN",12)); wbox.addView(winT);
        LinearLayout lbox=new LinearLayout(this); lbox.setOrientation(LinearLayout.VERTICAL); lossT=tv("0",44); lossT.setTextColor(Color.rgb(255,71,87)); lbox.addView(tv("LOSS",12)); lbox.addView(lossT);
        stats.addView(wbox,new LinearLayout.LayoutParams(0,140,1)); stats.addView(lbox,new LinearLayout.LayoutParams(0,140,1)); card.addView(stats);

        rateT=tv("",12); rateT.setTextColor(Color.LTGRAY); card.addView(rateT);

        LinearLayout sig=new LinearLayout(this); sig.setOrientation(LinearLayout.VERTICAL); sig.setGravity(Gravity.CENTER); sig.setPadding(10,20,10,20); sig.setBackground(bg(Color.rgb(6,27,59),28));
        sig.addView(tv("CURRENT SIGNAL",11));
        signalT=tv("BUY",38); signalT.setTypeface(null,1); sig.addView(signalT);
        sig.addView(tv("Expiry: 00:01",12)); card.addView(sig,new LinearLayout.LayoutParams(-1,180));

        LinearLayout buttons=new LinearLayout(this); buttons.setPadding(0,18,0,0);
        Button bw=new Button(this); bw.setText("WIN"); bw.setOnClickListener(v->{win++;update();});
        Button bl=new Button(this); bl.setText("LOSS"); bl.setOnClickListener(v->{loss++;update();});
        buttons.addView(bw,new LinearLayout.LayoutParams(0,75,1)); buttons.addView(bl,new LinearLayout.LayoutParams(0,75,1)); card.addView(buttons);

        LinearLayout small=new LinearLayout(this);
        Button reset=new Button(this); reset.setText("↻ RESET"); reset.setOnClickListener(v->{win=0;loss=0;update();});
        Button change=new Button(this); change.setText("⚙ SIGNAL"); change.setOnClickListener(v->{buy=!buy;update();});
        small.addView(reset,new LinearLayout.LayoutParams(0,70,1)); small.addView(change,new LinearLayout.LayoutParams(0,70,1)); card.addView(small);
        update();
    }
    void update(){
        winT.setText(""+win); lossT.setText(""+loss);
        int total=win+loss; double p=total==0?0:(win*100.0/total);
        rateT.setText(String.format("Winrate: %.1f%% (%d/%d)",p,win,total));
        signalT.setText(buy?"BUY":"SELL"); signalT.setTextColor(buy?Color.rgb(101,244,108):Color.rgb(255,83,100));
    }
}
