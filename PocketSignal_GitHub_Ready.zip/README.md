# PocketSignal Android

Native Android project for the PocketSignal demo dashboard.

## Build on GitHub
1. Upload all files to a GitHub repository.
2. Open **Actions**.
3. Select **Build PocketSignal APK**.
4. Tap **Run workflow**.
5. When finished, open the workflow run and download **PocketSignal-debug**.

This app is a signal-display/demo interface. It does not place trades automatically.
